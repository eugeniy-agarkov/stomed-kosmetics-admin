<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static OptionOne()
 * @method static static OptionTwo()
 * @method static static OptionThree()
 */
final class FormEnum extends Enum
{
    const FEEDBACK =   1;
    const APPOINTMENTS =   2;
}
